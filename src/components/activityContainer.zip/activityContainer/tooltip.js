import React, { memo, useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import PermIdentityIcon from '@material-ui/icons/PermIdentity';
import CalendarTodayIcon from '@material-ui/icons/CalendarToday';
import ScheduleIcon from '@material-ui/icons/Schedule';
import PinDropIcon from '@material-ui/icons/PinDrop';
import DeleteIcon from '@material-ui/icons/Delete';
import './index.css';
import moment from 'moment'

const size = {
  width: 200,
  height: 175,
};

const useStyles = makeStyles(theme => ({
  divider: {
    borderTop: '1px solid #ccc',
  },
  edtbtn: {
    width: 70,    
    backgroundColor: '#3d83bc',
    '&:hover': {
      backgroundColor: '#3d83bc',
    },
  },
  delbtn: {
    color: 'red',    
  },
  deleteWrapper: {
    color: '#4c5956',
    padding: 7,
  },
  deleteQuiz: {
    fontSize: '17px',
    fontWeight: 'bold',
  },
  cancel: {
    height: '50px',
    width: '100%',
    padding: '2px'
  },
  delbtn: {
      width: 80,
      color: 'red',
      marginTop: 4
  },
  yes_btn:{
    height: '50px',
    width: '100%',
    padding: '2px',
    backgroundColor: '#3d8ccb'
  }
}));

const Tooltip = memo(({ info }) => {
  const classes = useStyles();
  const [d_flag, setDFlage] = useState(false)

  useEffect(() => {
    setDFlage(false)
  },[info])
  
  const handleDeletePopper = () => {
    setDFlage(true)
  }

  const handleCancel = () => {
    setDFlage(false)
  }

  const handleYes = () => {
    
  }

  return (
    <>
      <Grid
        container
        spacing={1}
        direction="column"
        className={`tip-${info.dir}`}
        style={{        
          left: info.dir === 'left' ? info.x : info.x - size.width,  
          visibility: !d_flag && info.show ? "visible" : "hidden",      
          top: info.y - size.height / 2,
          width: size.width,
          height: size.height,
          color: '#a0a3a3',        
          fontSize: 12
        }}
      >
        <Grid item style={{marginLeft: 4, marginTop: 8}}>
          <span style={{ color: info.color }}>&nbsp;&nbsp;⬤</span>
          &nbsp;&nbsp;&nbsp;{parseFloat(info.data.score).toFixed(2)}%
        </Grid>
        <Grid item style={{marginLeft: 4}}>
          {/* {info.trials_correct} */}
        </Grid>
        <Grid item style={{marginLeft: 4}}>
          <PermIdentityIcon /> {info.observerName}
        </Grid>
        <Grid item style={{marginLeft: 4}}>
          {/* <CalendarTodayIcon /> {moment(info.data.date).format('D-MMMM-YYYY')} */}
        </Grid>
        <Grid item style={{marginLeft: 4}}>
          <ScheduleIcon /> {moment(info.data.date).format('LT')}
        </Grid>
        <Grid item style={{marginLeft: 4}}>
          {/* <PinDropIcon /> Classroom */}
        </Grid>
        <Grid item className={classes.divider}>
          <Grid container justify="space-around" alignItems="center">
            <Button size="small" variant="contained" color="primary" className={classes.edtbtn} disabled>
              Edit
            </Button>
            <Button size="small" className={classes.delbtn} onClick={handleDeletePopper} disabled>
              <DeleteIcon />
              Delete
            </Button>
          </Grid>
        </Grid>
      </Grid>
      <div
        className='delete-modal'
        style={{
          left: info.dir === 'left' ? info.x : info.x - 330, 
          top: info.y - 100,
          visibility: d_flag ? "visible" : "hidden",
          width: 330,
        }}
      >
        <Grid container spacing={1} className={classes.deleteWrapper}>
          <Grid item xs={12} className={classes.deleteQuiz}>
              Delete Data Point?
          </Grid>
          <Grid item xs={12}>
              Please confirm you want to delete 5 frequency <br/>
              count on <b>August 14</b> for <b>Behavior Name</b>.
          </Grid>
          <Grid item xs={12} style={{fontWeight: 'bold'}}>
              This Action cannot be undone.    
          </Grid>
          <Grid item xs={12}>
            <Grid container spacing={1} justify="center">
              <Grid container item xs={4}></Grid>
              <Grid container item xs={4}>
                <Button size="small" className={classes.cancel} onClick={handleCancel}>
                  No, Cancel
                </Button>
              </Grid>
              <Grid container item xs={4}>
                <Button
                    size="small"
                    variant="contained"
                    color="default"             
                    className={classes.yes_btn}
                    onClick={handleYes}
                    disabled
                  >
                    Yes, Delete
                </Button>
              </Grid>
            </Grid>            
          </Grid>        
        </Grid>
      </div>
    </>
  );
});

export default Tooltip;
